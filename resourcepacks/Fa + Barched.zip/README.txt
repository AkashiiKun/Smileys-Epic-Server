All credit to zzik2 (Barched Dev), and FreshLX, creator of "Fresh Animations"!

The pack includes edits of the Barched parched animations and his model.

EntityModelTextures+EntityModelFeatures is required for the model to function. Make sure this pack is placed /above/ Fresh Animations.